const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const bodyParser = require('body-parser');

const app = express();
const server = http.createServer(app);
const io = socketIO(server);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/main.html');
});

// Kullanıcı adı alındıktan sonra yönlendirme işlemi
app.post('/set-username', (req, res) => {
  const username = req.body.username;
  console.log('Kullanıcı adı => ', username, ', bağlandı ');

  io.emit('new-username', username);

  // Yönlendirme örneği:
  res.redirect('main.html');
});

/*/ Yönlendirme endpoint'i
app.get('/redirect-to-index', (req, res) => {
  res.sendFile(__dirname + '/main.html');
});*/

io.on('connection', (socket) => {
  //console.log('Kullanıcı bağlandı.');

  socket.on('chat message', (msg) => {
    io.emit('chat message', msg);
  });

  socket.on('disconnect', () => {
  //  console.log('Kullanıcı ayrıldı.');
  });
});

server.listen(3000, () => {
  console.log('Server "http://localhost:3000" çalışıyor');
});